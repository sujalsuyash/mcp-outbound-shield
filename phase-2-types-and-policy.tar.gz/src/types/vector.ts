// Type: which element/attribute/node a URL came from.
export const VECTORS = [
  "markdown_image",
  "markdown_definition",
  "markdown_link",
  "markdown_autolink",
  "html_img_src",
  "html_a_href"
] as const;

export type Vector = (typeof VECTORS)[number];

/** Auto-fetch vectors load without a click; link vectors need a click (unless the UI unfurls). */
export type VectorKind = "auto_fetch" | "link";
