// The raw policy used by the spec test matrix (SPEC.md section 14).
export const MATRIX_POLICY_RAW = {
  version: 1,
  on_violation: "strip_node",
  on_error: "drop_message",
  link_handling_mode: "defang_untrusted",
  allowlist: {
    "github.com": {
      allowed_paths: ["/my-org/assets/*.png"],
      allow_query: false,
      max_uri_length: 250
    },
    "api.corp.internal": {
      allowed_paths: ["/chart/*"],
      allow_query: true,
      allowed_query_params: ["theme", "size"],
      max_param_value_length: 10
    },
    "static.internal": {
      allowed_subdomains: ["cdn"],
      allowed_paths: ["/img/*.png"],
      allow_query: false
    }
  }
} as const;
